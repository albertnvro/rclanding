import React from 'react';

const Step2 = ({ nextStep }) => {
  return (
    <div>
      {/* Contenido del Paso 1 */}
      {/* Formulario o contenido para el Paso 1 */}
      <button onClick={nextStep}>Siguiente</button>
    </div>
  );
};

export default Step2;
